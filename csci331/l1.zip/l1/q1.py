# CSCI 331 - Lab 1
# Author:
# Date:

from pytictoc import TicToc
import sys

class LabOne:

	al = [] # all lines
	result = 0

	def readFile(self, fn: str) -> None:
		#WRITE YOUR CODE HERE
		pass

	def process(self) -> None:
		#WRITE YOUR CODE HERE
		pass

	def getResult(self) -> int:
		#WRITE YOUR CODE HERE
		pass



if __name__ == '__main__':
	#DO NOT MODIFY THIS CODE
	t = TicToc()
	t.tic() # start timer

	solution = LabOne()
	solution.readFile(sys.argv[1])
	if solution.al:
		solution.process()

	print('*' * 7)
	print('*' * 13)
	print(solution.getResult())
	t.toc() #elapsed time
	print('*' * 13)

